import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, peak_widths, fftconvolve
import scipy.constants as sc
from scipy.optimize import curve_fit
import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import functions as f
import matplotlibcolors
from filters.filters import load_all_filters


def count_pulses(dir, kid, pread, nr_req_files, filter, lifetime, mph, mpp, coord='circle', response='phase'):
    dir = dir.replace("\\", '/')
    pulse_files, _ = f.get_files(dir, kid, pread, type='vis')
    nr_files = len(pulse_files)

    if nr_req_files >= nr_files:
        nr_req_files = nr_files
    amp, phase, _ = f.get_data(pulse_files[:nr_req_files])
    signal = f.coord_transformation(phase, amp, coord=coord, response=response)
    if filter:
        window = f.get_window(filter, lifetime)
        signal = fftconvolve(signal, window, mode='valid')
    std = f.get_sigma(signal, window)
    ph = mph*std
    pp = mpp*std
    locs, _ = f.find_pks(signal, ph[0], pp, window)
    total_pulses = len(locs)
    return total_pulses, nr_req_files


def planck_wl(wl, t):
    return sc.h * sc.c**2 / (wl**5 * (np.exp(sc.h * sc.c / (wl * sc.k * t)) - 1))


def get_index(x, val, round):
    idx = np.argmin(np.absolute(x-val))
    if round=='floor':
        if x[idx] > val:
            idx -= 1
    elif round=='ceil':
        if x[idx] < val:
            idx += 1
    return idx


def int_pow(y, x, x1, x2):
    idx = np.arange(get_index(x, x1*1e-6, 'floor'), get_index(x, x2*1e-6, 'ceil')+1, 1)
    pow = np.trapz(y[idx], x[idx])
    return pow


def get_bp(theta, mph):
    fig, ax = plt.subplots()
    ax.plot(theta)
    locs, _ = find_peaks(theta, height=mph, prominence=mph)
    width_full = peak_widths(theta, locs, rel_height=.99)
    bp = width_full[2:]
    ax.axvline(locs[0], c='k')
    ax.hlines(*width_full[1:], color='r')
    for edge in bp:   
        ax.axvline(edge, c='tab:red')
    idx = np.arange(np.floor(bp[0]), np.ceil(bp[1]), dtype=int)
    return idx


# kid = 5
# pread = 113
# file_type = 'vis'
# pw = 1500
# pw_offset = 100
# filter = 'exp'
# lifetime = 250
# tqp = [200, 600]
# iterate = 0
# nr_req_files = 20
# mph = np.array([5, 20])
# mpp = mph[0] 
    
# dir = r'D:\Data\LT218Chip1_BF_20240116_MIR18_5\KID5_all_temps'
# temps = [3,30,50,85,100,135,142,150,160,180]
# Nph = []
# fig, ax = plt.subplot_mosaic('a')

# for temp in temps:
#     path = dir + '/' + str(temp) + 'K'
#     nr_pulses, nr_analyzed_files = count_pulses(path, kid, pread, nr_req_files, filter, lifetime, mph, mpp, coord='circle', response='phase')
#     Nph.append(nr_pulses/(nr_analyzed_files))
#     print('Temp: %d K, Nph: %.1f' % (temp, Nph[-1]))
# ax['a'].scatter(temps, Nph)
# Nph = np.array(Nph)
# np.save('figures/Nph_KID5_113dBm_40s.npy', Nph)
# plt.show()

Nph = np.load('figures/Nph_KID5_113dBm_40s.npy')
Eph = sc.h*sc.c/(18.5e-6)
absorbed_powers = Nph/40*Eph


filters = load_all_filters()
temps = [3,30,50,85,100,135,142,150,160,180]

wl = filters['wl']*1e6
bp185 = filters['bp185']
znse = filters['znse']
nd1 = filters['nd1']
nd3 = filters['nd3']
ger = filters['ger'] 
bp25 = filters['bp25']
sp_a = filters['sp_a']
sp_b = filters['sp_b']
lp = filters['lp']
si = filters['si']


A = (1e-3)**2
omega = np.pi*(10e-3)**2/(300e-3)**2
tot185 = bp185**5*nd1*nd3*znse**2*si*A*omega
tot25 = bp25**3*lp*sp_a**3*sp_b*si*A*omega
inband = get_bp(bp185, .5)

def get_power(temp, a):
    bb = planck_wl(wl*1e-6, np.array(temp).reshape((-1,1)))
    radiance = tot185*bb
    return np.log10(a) + np.log10(np.trapezoid(radiance[:,inband], wl[inband]))

fit_idx = 4
[a], pcov = curve_fit(get_power, temps[fit_idx:], np.log10(absorbed_powers[fit_idx:]))

fig, ax = plt.subplots()
ax.scatter(temps[fit_idx:], absorbed_powers[fit_idx:], marker='o', facecolor='w', edgecolor='o', linewidth=2, label='Data')
ax.scatter(temps[:fit_idx], absorbed_powers[:fit_idx], marker='o', facecolor='o', edgecolor='w', linewidth=2)
t = np.linspace(3,200,100)
ax.semilogy(t, 10**get_power(t, a), ls='--', c='k', label='Fit, a=%.2e' % a)
ax.set_ylim(1e-22,1e-19)
ax.set_xlim(0,200)
ax.set_ylabel('Power [W]')
ax.legend()
plt.show()
